# thehmstudio website

A responsive jewellery catalogue starter for thehmstudio.

## Preview
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Upload the contents of this folder to the root of your GitHub repository (not the ZIP file).
2. In the repository, open Settings -> Pages.
3. Under Build and deployment choose Deploy from a branch.
4. Select branch `main` and folder `/(root)`, then Save.
5. Wait for GitHub Pages to publish and use the URL shown on the Pages screen.

## Product manager limitation
The Manage your products section stores edits in the current browser's local storage only. It is suitable for local preview, not shared public product management. To manage products securely and have updates appear for all visitors, connect a database/backend and authenticated admin login before relying on it publicly.

The included products and prices are sample placeholders. Replace them with your actual product details and images before publishing.
